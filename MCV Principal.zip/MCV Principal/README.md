# CASO 1 MVC

## Hallar el mayor de 2 números enteros